import { useState } from 'react'
import './App.css'
import Header from './Header'
import Sidebar from './sidebar'
import Home from './home'

function App() {
  const [opensidebarToggle, setOpensidebarToggle] = useState(false)

  const Opensidebar = () => {
    setOpensidebarToggle(!opensidebarToggle)
  }

  return (
    <div className='grid-container'>
      <Header Opensidebar={Opensidebar}/>
      <Sidebar opensidebarToggle={opensidebarToggle} Opensidebar={Opensidebar}/>
      <Home />
    </div>
  )
}

export default App
